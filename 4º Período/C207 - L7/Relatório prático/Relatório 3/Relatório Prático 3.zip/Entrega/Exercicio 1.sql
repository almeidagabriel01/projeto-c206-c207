# letra A
ALTER TABLE super_heroi ADD COLUMN acessorio VARCHAR(100);

# letra B
ALTER TABLE super_vilao CHANGE tipo especie VARCHAR(50);

#letra C
ALTER TABLE super_heroi DROP idade;