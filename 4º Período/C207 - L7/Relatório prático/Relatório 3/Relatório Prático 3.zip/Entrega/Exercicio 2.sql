# letra A
GRANT INSERT, UPDATE
ON super_heroi
TO Batman@localhost;

# letra B
GRANT DROP
ON super_vilao
TO WonderWoman@localhost;

# letra C
REVOKE INSERT
ON *
FROM Superman@localhost;