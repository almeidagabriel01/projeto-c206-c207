package Exceptions;

public class JaAdicionadoUnChecked extends RuntimeException {
    public JaAdicionadoUnChecked(String message) {
        super(message);
    }
}
