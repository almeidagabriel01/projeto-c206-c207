package Exceptions;

public class NenhumaCriancaUnChecked extends RuntimeException {
    public NenhumaCriancaUnChecked(String mensagem) {
        super(mensagem);
    }
}
